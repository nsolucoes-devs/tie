<?php

class MY_Controller extends CI_Controller {
    /*
     * Este controller deve estender o CI_Controller normalmente, pois aqui não precisamos fazer verificação de senha, já que
     * não tem sentido querer proteger a tela de login. ;)
     * A função abaixo simplesmente verifica se o conteúdo da variável logado na sessão é igual a 1, caso seja, então, então não faz nada, caso não seja
     * então redireciona novamente para o controller de login.
     */
    public function __construct()
    {
        parent::__construct();

        $logado = $this->session->userdata("logado");
        
        if ($logado != TRUE){
            redirect(base_url('login'));
        }
        
        $this->logger();
        
    }
    
    //Carrega a view de header
    public function header($id = null, $manual = null){
        $this->load->database();
        $this->load->model('permissoes');
        
        $userid = $this->session->userdata("user_id");
        $dados['perm'] = $this->permissoes->getPermissaoUsuario($userid);
        $dados['idpag'] = $id;
        $dados['manual'] = $manual;
        $this->load->view('recursos/restrito/header', $dados);
    }
    
    //Carrega a view de footer
    public function footer(){
        $this->load->view('recursos/restrito/footer');
    }
    
    //Carrega a view de header2
    public function header2(){
        $this->load->view('recursos/restrito/header2');
    }
    
    //Carrega a view de footer 2
    public function footer2(){
        $this->load->view('recursos/restrito/footer2');
    }
    
    //Registra os controllers e funções que estão sendo acessadas
    public function logger(){
        $this->load->database();
        $this->load->model('logger');
        date_default_timezone_set('America/Sao_Paulo');
        
        $log = array(
            'nome_log' => $this->session->userdata('nome'),
            'datahora_log' => date('d/m/Y H:i:s'),
            'usuario_id' => $this->session->userdata('user_id'),
            'controller_log' => $this->uri->segment(1) . "/" . $this->uri->segment(2),
        );
        
        $this->logger->adicionarLog($log);
        
    }
}
